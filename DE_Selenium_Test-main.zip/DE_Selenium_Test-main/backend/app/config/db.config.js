module.exports = {
  url: "mongodb+srv://user1:pass123@cluster0.nrbf5.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
};
